var store = [{
        "title": "TBA",
        "excerpt":"an abstract …   ","categories": [],
        "tags": [],
        "url": "/rosolini/talks/awodey/",
        "teaser": "/rosolini/assets/images/bio-photo-2.jpg"
      },{
        "title": "TBA",
        "excerpt":"an abstract …   ","categories": [],
        "tags": [],
        "url": "/rosolini/talks/maietti/",
        "teaser": "/rosolini/assets/images/bio-photo-2.jpg"
      },{
        "title": "TBA",
        "excerpt":"an abstract …   ","categories": [],
        "tags": [],
        "url": "/rosolini/talks/mantovani/",
        "teaser": "/rosolini/assets/images/bio-photo-2.jpg"
      },{
        "title": "TBA",
        "excerpt":"an abstract …   ","categories": [],
        "tags": [],
        "url": "/rosolini/talks/moggi/",
        "teaser": "/rosolini/assets/images/bio-photo-2.jpg"
      },{
        "title": "TBA",
        "excerpt":"an abstract …   ","categories": [],
        "tags": [],
        "url": "/rosolini/talks/robinson/",
        "teaser": "/rosolini/assets/images/bio-photo-2.jpg"
      },{
        "title": "TBA",
        "excerpt":"an abstract …   ","categories": [],
        "tags": [],
        "url": "/rosolini/talks/streicher/",
        "teaser": "/rosolini/assets/images/bio-photo-2.jpg"
      },{
        "title": "TBA",
        "excerpt":"an abstract …   ","categories": [],
        "tags": [],
        "url": "/rosolini/talks/van-oosten/",
        "teaser": "/rosolini/assets/images/bio-photo-2.jpg"
      },{
        "title": "TBA",
        "excerpt":"an abstract …   ","categories": [],
        "tags": [],
        "url": "/rosolini/talks/vitale/",
        "teaser": "/rosolini/assets/images/bio-photo-2.jpg"
      }]
